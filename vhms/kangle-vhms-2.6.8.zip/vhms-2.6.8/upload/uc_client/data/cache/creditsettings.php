<?php
$_CACHE['creditsettings'] = array (
  '3|1' => 
  array (
    'title' => 'vhms ���',
    'unit' => '',
    'ratiosrc' => 
    array (
      2 => '1',
    ),
    'ratiodesc' => 
    array (
      2 => '100',
    ),
    'creditsrc' => 
    array (
      2 => '0.01',
    ),
  ),
);
