<?php
$GLOBALS['settingrule']['alipay']['ALIPAY_SELLER_EMAIL'] = array('name'=>'ALIPAY_SELLER_EMAIL','value'=>array('TEXT','/.*/',32));
$GLOBALS['settingrule']['alipay']['ALIPAY_KEY'] = array('name'=>'ALIPAY_KEY','password'=>1,'value'=>array('TEXT','/.*/',32));
$GLOBALS['settingrule']['alipay']['ALIPAY_PARTNER'] = array('name'=>'ALIPAY_PARTNER','value'=>array('TEXT','/.*/',32));
$GLOBALS['settingrule']['alipay']['ALIPAY_MAINNAME'] = array('name'=>'ALIPAY_MAINNAME','value'=>array('TEXT','/.*/',32));


$GLOBALS['lang']['zh_CN']['ALIPAY_SELLER_EMAIL'] = '支付宝账号';
$GLOBALS['lang']['zh_CN']['ALIPAY_KEY'] = '支付宝安全码(key),仅修改时输入';
$GLOBALS['lang']['zh_CN']['ALIPAY_PARTNER'] = '合作身份者ID';
$GLOBALS['lang']['zh_CN']['ALIPAY_MAINNAME'] = '收款方名称';

?>