	$(document).ready(function(){
		$("li >span").before("<img src='/style/dns_t.gif'>&nbsp;");
	});

function piao_prio(val)
{
	if (val =='MX') {
		document.getElementById('prio_td').style.display = 'block';
		document.getElementById('prio_text').style.display = 'block';
	}else{
		document.getElementById('prio_td').style.display = 'none';
		document.getElementById('prio_text').style.display = 'none';
	}
}
function close_piao()
{
	document.getElementById('msg').style.display = 'none';
}
function piao_change()
{
	$("#msg").html("");
	var msg = "<form method='post' action='javascript:change_passwd()'>";
		msg += "<div class='div_1'>新密码:</div><div class='div_2'><input name='passwd' id='change_passwd'></div>";
		msg += "<div class='div_submit'><input type='submit' value='提交'><input type='button' onclick='close_piao();' value='关闭'></div>";
		msg += "</form>";
		
	$("#msg").append(msg);
	document.getElementById('msg').style.display = 'block';
}
function change_passwd()
{
	var p = $("#change_passwd").val();
	if (p == "") {
		return;
	}
	$.ajax({
		type:'post',
		url: '?c=session&a=changePasswd',
		data:'passwd=' + p,
		success:function(msg){
			alert(msg);
			//window.location.reload();
			document.getElementById('msg').style.display = 'none';
		}
	});
}
function record_update(id,n,type,value,view,ttl,prio)
{
	var f = document.getElementById('from');
	if (f != null && f != 'undefined') {
		f.action += '&id=' +id;
	}
	document.getElementById('name').value = n;
	document.getElementById('type').value = type;
	document.getElementById('value').value = value;
	document.getElementById('view').value = view;
	document.getElementById('ttl').value = ttl;
	if (type == 'MX') {
		document.getElementById('prio').value = prio;
		document.getElementById('prio_td').style.display = 'block';
		document.getElementById('prio_text').style.display = 'block';
	}
}